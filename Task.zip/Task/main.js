let sendBtn = document.getElementById('send');
let form = document.getElementById('form');

//Form
form.addEventListener('submit', (e) => {
    e.preventDefault();
});

//send
sendBtn.addEventListener('click', (e) => {
    let name = document.getElementById('name');
    let contactno = document.getElementById('contactno');
    let email = document.getElementById('email');
    let message = document.getElementById('message');

    //LocalStorage
    
    name = name.value;
    localStorage.setItem('name', name);

    contactno = contactno.value;
    localStorage.setItem('contactno', contactno);

    email = email.value;
    localStorage.setItem('email', email);

    message = message.value;
    localStorage.setItem('message', message);

});


//validation

function validation(){

    let name = document.getElementById('name').value;
    let cno = document.getElementById('contactno').value;
    let email = document.getElementById('email').value;

//name
    if(name == ""){
        document.getElementById('username').innerHTML =" ** Please fill the name field";
        return false;
    }
    if((name.length <= 2) || (user.length > 20)) {
        document.getElementById('username').innerHTML =" ** name lenght must be between 5 and 15";
        return false;	
    }
    if(!isNaN(user)){
        document.getElementById('username').innerHTML =" ** only characters are allowed";
        return false;
    }

//contactno
    if(cno == ""){
        document.getElementById('contactno').innerHTML =" ** Please fill the mobile NUmber field";
        return false;
    }
    if(isNaN(cno)){
        document.getElementById('contactno').innerHTML =" ** user must write digits only not characters";
        return false;
    }
    if(cno.length<10){
        document.getElementById('contactno').innerHTML =" ** Mobile Number must be 10 digits only";
        return false;
    }
    if(cno.length>10){
        document.getElementById('contactno').innerHTML =" ** Mobile Number must be 10 digits only";
        return false;
    }
}
